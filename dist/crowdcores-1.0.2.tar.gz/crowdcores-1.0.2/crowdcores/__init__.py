# crowdcores/crowdcores/__init__.py
