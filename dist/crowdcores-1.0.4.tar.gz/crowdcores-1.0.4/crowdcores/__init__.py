# crowdcores/__init__.py
from .pipeline import crowdcores_pipeline

__all__ = ['crowdcores_pipeline']
